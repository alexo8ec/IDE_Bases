#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
printf 'Cierra AdisDB antes de instalar. Presiona Enter para continuar. / Close AdisDB, then press Enter.\n'
read -r confirmation
mkdir -p "$HOME/Applications"
/usr/bin/ditto "$root/AdisDB.app" "$HOME/Applications/AdisDB.app"
printf 'Instalado en ~/Applications/AdisDB.app / Installed.\n'
/usr/bin/open "$HOME/Applications/AdisDB.app"
