#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
printf 'Cierra NexoDB Studio antes de instalar. Presiona Enter para continuar. / Close NexoDB Studio, then press Enter.\n'
read -r confirmation
mkdir -p "$HOME/Applications"
/usr/bin/ditto "$root/NexoDB Studio.app" "$HOME/Applications/NexoDB Studio.app"
printf 'Instalado en ~/Applications/NexoDB Studio.app / Installed.\n'
/usr/bin/open "$HOME/Applications/NexoDB Studio.app"
